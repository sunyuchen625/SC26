#ifndef SC26_QUAD_HALO_H
#define SC26_QUAD_HALO_H

#include <stdio.h>
#include <stdlib.h>

#include "solverchallenge26/solver_input.h"

struct QuadHalo {
    const struct SC26_SolverInput *input;
    MPI_Datatype scalar;
    int *recv_counts, *recv_displs, *send_counts, *send_displs;
    int *send_indices, *columns;
    __float128 *send_values, *ghost_values;
    int send_size;
};

static void *quad_halo_alloc(MPI_Comm comm, int count, size_t item_size)
{
    void *p = calloc((size_t)(count ? count : 1), item_size);
    if (!p) {
        fprintf(stderr, "T2 halo allocation failed (%d elements of %zu bytes)\n", count, item_size);
        MPI_Abort(comm, 2);
    }
    return p;
}

static int quad_halo_compare(const void *lhs, const void *rhs)
{
    const int a = *(const int *)lhs, b = *(const int *)rhs;
    return (a > b) - (a < b);
}

static struct QuadHalo *quad_halo_create(const struct SC26_SolverInput *input)
{
    MPI_Comm comm = input->comm;
    struct QuadHalo *h = quad_halo_alloc(comm, 1, sizeof(*h));
    h->input = input;
    int size;
    MPI_Comm_size(comm, &size);
    MPI_Type_contiguous(sizeof(__float128), MPI_BYTE, &h->scalar);
    MPI_Type_commit(&h->scalar);

    int *starts = quad_halo_alloc(comm, size, sizeof(*starts));
    MPI_Allgather(&input->row_begin, 1, MPI_INT, starts, 1, MPI_INT, comm);
    const int begin = input->row_begin, end = begin + input->local_n;
    const int nnz = input->row_ptr[input->local_n];
    int *ghosts = quad_halo_alloc(comm, nnz, sizeof(*ghosts));
    int count = 0;
    for (int k = 0; k < nnz; ++k) {
        int col = input->col_idx[k];
        if (col < begin || col >= end)
            ghosts[count++] = col;
    }
    qsort(ghosts, count, sizeof(*ghosts), quad_halo_compare);
    int unique = 0;
    for (int j = 0; j < count; ++j)
        if (j == 0 || ghosts[j] != ghosts[j - 1])
            ghosts[unique++] = ghosts[j];

    h->recv_counts = quad_halo_alloc(comm, size, sizeof(int));
    h->recv_displs = quad_halo_alloc(comm, size, sizeof(int));
    h->send_counts = quad_halo_alloc(comm, size, sizeof(int));
    h->send_displs = quad_halo_alloc(comm, size, sizeof(int));
    for (int j = 0, owner = 0; j < unique; ++j) {
        while (owner + 1 < size && starts[owner + 1] <= ghosts[j])
            ++owner;
        ++h->recv_counts[owner];
    }
    free(starts);
    MPI_Alltoall(h->recv_counts, 1, MPI_INT, h->send_counts, 1, MPI_INT, comm);
    for (int rank = 1; rank < size; ++rank) {
        h->recv_displs[rank] = h->recv_displs[rank - 1] + h->recv_counts[rank - 1];
        h->send_displs[rank] = h->send_displs[rank - 1] + h->send_counts[rank - 1];
    }
    h->send_size = h->send_displs[size - 1] + h->send_counts[size - 1];
    h->send_indices = quad_halo_alloc(comm, h->send_size, sizeof(*h->send_indices));
    MPI_Alltoallv(ghosts, h->recv_counts, h->recv_displs, MPI_INT,
                  h->send_indices, h->send_counts, h->send_displs, MPI_INT, comm);
    for (int j = 0; j < h->send_size; ++j)
        h->send_indices[j] -= begin;

    h->columns = quad_halo_alloc(comm, nnz, sizeof(*h->columns));
    for (int k = 0; k < nnz; ++k) {
        int col = input->col_idx[k];
        if (col >= begin && col < end)
            h->columns[k] = col - begin;
        else {
            const int *ghost = bsearch(&col, ghosts, unique, sizeof(*ghosts), quad_halo_compare);
            h->columns[k] = -(int)(ghost - ghosts) - 1;
        }
    }
    free(ghosts);
    h->send_values = quad_halo_alloc(comm, h->send_size, sizeof(*h->send_values));
    h->ghost_values = quad_halo_alloc(comm, unique, sizeof(*h->ghost_values));
    return h;
}

static void quad_matvec(struct QuadHalo *h, const __float128 *x, __float128 *y)
{
    for (int j = 0; j < h->send_size; ++j)
        h->send_values[j] = x[h->send_indices[j]];
    MPI_Alltoallv(h->send_values, h->send_counts, h->send_displs, h->scalar,
                  h->ghost_values, h->recv_counts, h->recv_displs, h->scalar,
                  h->input->comm);

    const int *rows = h->input->row_ptr;
    const double *values = h->input->val;
    for (int i = 0; i < h->input->local_n; ++i) {
        __float128 sum = 0;
        for (int k = rows[i]; k < rows[i + 1]; ++k) {
            int col = h->columns[k];
            __float128 entry = col >= 0 ? x[col] : h->ghost_values[-col - 1];
            sum += (__float128)values[k] * entry;
        }
        y[i] = sum;
    }
}

static void quad_halo_destroy(struct QuadHalo *h)
{
    MPI_Type_free(&h->scalar);
    free(h->recv_counts);
    free(h->recv_displs);
    free(h->send_counts);
    free(h->send_displs);
    free(h->send_indices);
    free(h->columns);
    free(h->send_values);
    free(h->ghost_values);
    free(h);
}

#endif
