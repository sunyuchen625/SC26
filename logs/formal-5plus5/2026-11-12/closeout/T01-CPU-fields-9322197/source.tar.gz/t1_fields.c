#include <HYPRE.h>
#include <HYPRE_IJ_mv.h>
#include <HYPRE_parcsr_ls.h>
#include <math.h>
#include <mpi.h>
#include <omp.h>
#include <quadmath.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "solverchallenge26/diagnostics.h"
#include "solverchallenge26/system_loader.h"

struct Block {
    HYPRE_IJMatrix matrix;
    HYPRE_IJVector rhs, sol;
    HYPRE_Solver amg, pcg;
    HYPRE_ParCSRMatrix par_matrix;
    HYPRE_ParVector par_rhs, par_sol;
    HYPRE_Int *indices;
    double *scale, *rhsval, *solval;
};

static void hypre_ok(int rc, const char *call)
{
    if (rc) {
        fprintf(stderr, "%s failed: %d\n", call, rc);
        exit(2);
    }
}

#define HYPRE_DO(call) hypre_ok((call), #call)

static void create_block(struct Block *block, int n)
{
    block->indices = malloc((size_t)n * sizeof(*block->indices));
    block->scale = malloc((size_t)n * sizeof(double));
    block->rhsval = malloc((size_t)n * sizeof(double));
    block->solval = calloc((size_t)n, sizeof(double));
    if (!block->indices || !block->scale || !block->rhsval || !block->solval)
        exit(2);
    for (int i = 0; i < n; ++i) block->indices[i] = i;

    HYPRE_DO(HYPRE_IJMatrixCreate(MPI_COMM_SELF, 0, n-1, 0, n-1, &block->matrix));
    HYPRE_DO(HYPRE_IJMatrixSetObjectType(block->matrix, HYPRE_PARCSR));
    HYPRE_Int *sizes = malloc((size_t)n * sizeof(*sizes));
    if (!sizes) exit(2);
    for (int i = 0; i < n; ++i) sizes[i] = 7;
    HYPRE_DO(HYPRE_IJMatrixSetRowSizes(block->matrix, sizes));
    free(sizes);
    HYPRE_DO(HYPRE_IJMatrixInitialize(block->matrix));

    HYPRE_DO(HYPRE_IJVectorCreate(MPI_COMM_SELF, 0, n-1, &block->rhs));
    HYPRE_DO(HYPRE_IJVectorSetObjectType(block->rhs, HYPRE_PARCSR));
    HYPRE_DO(HYPRE_IJVectorInitialize(block->rhs));
    HYPRE_DO(HYPRE_IJVectorAssemble(block->rhs));
    HYPRE_DO(HYPRE_IJVectorGetObject(block->rhs, (void **)&block->par_rhs));
    HYPRE_DO(HYPRE_IJVectorCreate(MPI_COMM_SELF, 0, n-1, &block->sol));
    HYPRE_DO(HYPRE_IJVectorSetObjectType(block->sol, HYPRE_PARCSR));
    HYPRE_DO(HYPRE_IJVectorInitialize(block->sol));
    HYPRE_DO(HYPRE_IJVectorAssemble(block->sol));
    HYPRE_DO(HYPRE_IJVectorGetObject(block->sol, (void **)&block->par_sol));

    HYPRE_DO(HYPRE_BoomerAMGCreate(&block->amg));
    HYPRE_DO(HYPRE_BoomerAMGSetCoarsenType(block->amg, 10));
    HYPRE_DO(HYPRE_BoomerAMGSetInterpType(block->amg, 6));
    HYPRE_DO(HYPRE_BoomerAMGSetPMaxElmts(block->amg, 4));
    HYPRE_DO(HYPRE_BoomerAMGSetStrongThreshold(block->amg, 0.5));
    HYPRE_DO(HYPRE_BoomerAMGSetRelaxType(block->amg, 6));
    HYPRE_DO(HYPRE_BoomerAMGSetMaxIter(block->amg, 1));
    HYPRE_DO(HYPRE_BoomerAMGSetTol(block->amg, 0));
    HYPRE_DO(HYPRE_ParCSRPCGCreate(MPI_COMM_SELF, &block->pcg));
    HYPRE_DO(HYPRE_ParCSRPCGSetMaxIter(block->pcg, 180));
    HYPRE_DO(HYPRE_ParCSRPCGSetTwoNorm(block->pcg, 1));
    HYPRE_DO(HYPRE_ParCSRPCGSetTol(block->pcg, 1e-10));
    HYPRE_DO(HYPRE_ParCSRPCGSetPrintLevel(block->pcg, 0));
    HYPRE_DO(HYPRE_ParCSRPCGSetLogging(block->pcg, 1));
    HYPRE_DO(HYPRE_ParCSRPCGSetPrecond(block->pcg, HYPRE_BoomerAMGSolve, HYPRE_BoomerAMGSetup, block->amg));
}

static void destroy_block(struct Block *block)
{
    HYPRE_DO(HYPRE_ParCSRPCGDestroy(block->pcg));
    HYPRE_DO(HYPRE_BoomerAMGDestroy(block->amg));
    HYPRE_DO(HYPRE_IJMatrixDestroy(block->matrix));
    HYPRE_DO(HYPRE_IJVectorDestroy(block->rhs));
    HYPRE_DO(HYPRE_IJVectorDestroy(block->sol));
    free(block->indices);
    free(block->scale);
    free(block->rhsval);
    free(block->solval);
}

static void build_block(struct Block *block, int n, int first, int anchor,
                        const int *ptr, const int *col, const double *val)
{
    for (int i = 0; i < n; ++i) {
        double diag = 0;
        for (int k = ptr[first+i]; k < ptr[first+i+1]; ++k)
            if (col[k] == first+i) diag = val[k];
        if (!(diag > 0)) exit(2);
        block->scale[i] = 1/sqrt(diag);
    }
    for (int begin = 0; begin < n; begin += 256) {
        HYPRE_Int counts[256], columns[7*256];
        double values[7*256];
        const int end = begin+256 < n ? begin+256 : n;
        int pos = 0;
        for (int i = begin; i < end; ++i) {
            const int start = pos;
            for (int k = ptr[first+i]; k < ptr[first+i+1]; ++k) {
                int j = col[k]-first;
                if (j < 0 || j >= n) continue;
                if ((i == anchor || j == anchor) && i != j) continue;
                if (pos-start == 7) exit(2);
                columns[pos] = j;
                values[pos++] = block->scale[i]*val[k]*block->scale[j];
            }
            counts[i-begin] = pos-start;
        }
        HYPRE_DO(HYPRE_IJMatrixSetValues(block->matrix, end-begin, counts,
            block->indices+begin, columns, values));
    }
    HYPRE_DO(HYPRE_IJMatrixAssemble(block->matrix));
    HYPRE_DO(HYPRE_IJMatrixGetObject(block->matrix, (void **)&block->par_matrix));
    HYPRE_DO(HYPRE_ParCSRPCGSetup(block->pcg, block->par_matrix, block->par_rhs, block->par_sol));
}

static void solve_block(struct Block *block, int n, int anchor,
                        const double *rhs, double *result, int field)
{
    for (int i = 0; i < n; ++i)
        block->rhsval[i] = i == anchor ? 0 : rhs[i]*block->scale[i];
    memset(block->solval, 0, (size_t)n * sizeof(double));
    HYPRE_DO(HYPRE_IJVectorSetValues(block->rhs, n, block->indices, block->rhsval));
    HYPRE_DO(HYPRE_IJVectorSetValues(block->sol, n, block->indices, block->solval));
    int rc = HYPRE_ParCSRPCGSolve(block->pcg, block->par_matrix, block->par_rhs, block->par_sol);
    if (rc & ~HYPRE_ERROR_CONV) hypre_ok(rc, "PCG solve");
    HYPRE_ClearAllErrors();
    HYPRE_Int iterations;
    HYPRE_Real residual;
    HYPRE_DO(HYPRE_ParCSRPCGGetNumIterations(block->pcg, &iterations));
    HYPRE_DO(HYPRE_ParCSRPCGGetFinalRelativeResidualNorm(block->pcg, &residual));
    printf("T1_BLOCK field=%d iterations=%d residual=%.6g\n", field, (int)iterations, (double)residual);
    if (!isfinite(residual)) exit(2);
    HYPRE_DO(HYPRE_IJVectorGetValues(block->sol, n, block->indices, block->solval));
    for (int i = 0; i < n; ++i) result[i] = block->solval[i]*block->scale[i];
}

static double relative_residual(int n, const int *ptr, const int *col, const double *val,
                                const double *rhs, const __float128 *x, double *resid,
                                long double rhs_norm_sq)
{
    long double norm_sq = 0;
    #pragma omp parallel for reduction(+:norm_sq)
    for (int i = 0; i < n; ++i) {
        __float128 r = rhs[i];
        for (int k = ptr[i]; k < ptr[i+1]; ++k)
            r -= (__float128)val[k]*x[col[k]];
        resid[i] = (double)r;
        norm_sq += (long double)r*(long double)r;
    }
    return sqrtl(norm_sq/rhs_norm_sq);
}

int main(int argc, char **argv)
{
    if (argc != 3 && !(argc == 4 && !strcmp(argv[3], "--probe"))) return 2;
    MPI_Init(&argc, &argv);
    HYPRE_DO(HYPRE_Initialize());
    int m, n, nnz, symmetric, *ptr, *col;
    double *val, *imag, *rhs, *rhs_imag;
    if (load_linear_system(argv[1], argv[2], 0, 0, &m, &n, &nnz, &symmetric, &ptr,
        &col, &val, &imag, &rhs, &rhs_imag) || m != n || n % 3) return 2;
    const int cells = n/3, third = 2*cells;
    printf("T1_MATRIX rows=%d nnz=%d cells=%d\n", n, nnz, cells);
    __float128 *x = calloc((size_t)n, sizeof(*x));
    double *resid = malloc((size_t)n*sizeof(double));
    double *delta = malloc((size_t)n*sizeof(double));
    double *d = malloc((size_t)cells*sizeof(double));
    double *dz = malloc((size_t)cells*sizeof(double));
    __float128 *column_sum = calloc((size_t)cells, sizeof(*column_sum));
    double *middle_diag = malloc((size_t)cells*sizeof(double));
    if (!x || !resid || !delta || !d || !dz || !column_sum || !middle_diag) return 2;
    long double rhs_norm_sq = 0;
    for (int i = 0; i < n; ++i) rhs_norm_sq += (long double)rhs[i]*rhs[i];
    struct Block first, last;
    create_block(&first, cells);
    create_block(&last, cells);

    const int rounds = argc == 4 ? 1 : 10;
    double formal_start = 0, totals = 0;
    for (int round = 0; round < rounds; ++round) {
        const double start = omp_get_wtime();
        if (round == 5) formal_start = start;
        memset(x, 0, (size_t)n*sizeof(*x));
        memset(column_sum, 0, (size_t)cells*sizeof(*column_sum));
        memcpy(resid, rhs, (size_t)n*sizeof(double));
        int anchor = -1;
        double anchor_diag = 0;
        __float128 sum_rows = 0;
        for (int i = 0; i < cells; ++i) {
            __float128 row_sum = 0;
            for (int k = ptr[third+i]; k < ptr[third+i+1]; ++k) {
                int j = col[k]-third;
                if (j < 0) continue;
                column_sum[j] += val[k];
                row_sum += val[k];
                if (i == j && val[k] > anchor_diag) {
                    anchor = i;
                    anchor_diag = val[k];
                }
            }
            d[i] = (double)row_sum;
            sum_rows += row_sum;
            for (int k = ptr[cells+i]; k < ptr[cells+i+1]; ++k)
                if (col[k] == cells+i) middle_diag[i] = val[k];
        }
        if (anchor < 0) return 2;
        printf("T1_MODE anchor=%d anchor_diag=%.12g row_sum=%.12Lg\n",
               anchor, anchor_diag, (long double)sum_rows);
        build_block(&first, cells, 0, -1, ptr, col, val);
        build_block(&last, cells, third, anchor, ptr, col, val);
        solve_block(&last, cells, anchor, d, dz, 2);
        __float128 denominator = 0;
        for (int i = 0; i < cells; ++i)
            denominator += column_sum[i]*(1-(__float128)dz[i]);
        printf("T1_MODE denominator=%.12Lg\n", (long double)denominator);
        if (denominator == 0) {
            fprintf(stderr, "T1 field-2 constant mode is singular under block splitting.\n");
            return 2;
        }
        double residual = 1;
        for (int it = 0; it < 12 && residual > 3e-10; ++it) {
            #pragma omp parallel for
            for (int i = 0; i < cells; ++i)
                delta[cells+i] = resid[cells+i]/middle_diag[i];
            #pragma omp parallel for
            for (int i = 0; i < cells; ++i) {
                for (int k = ptr[i]; k < ptr[i+1]; ++k)
                    if (col[k] >= cells && col[k] < third)
                        resid[i] -= val[k]*delta[col[k]];
                for (int k = ptr[third+i]; k < ptr[third+i+1]; ++k)
                    if (col[k] >= cells && col[k] < third)
                        resid[third+i] -= val[k]*delta[col[k]];
            }
            solve_block(&first, cells, -1, resid, delta, 0);
            solve_block(&last, cells, anchor, resid+third, delta+third, 2);
            __float128 numerator = 0;
            for (int i = 0; i < cells; ++i)
                numerator += (__float128)resid[third+i] - column_sum[i]*delta[third+i];
            const __float128 mean_step = numerator/denominator;
            #pragma omp parallel for
            for (int i = 0; i < cells; ++i) {
                x[i] += delta[i];
                x[cells+i] += delta[cells+i];
                x[third+i] += delta[third+i] + mean_step*(1-(__float128)dz[i]);
            }
            residual = relative_residual(n, ptr, col, val, rhs, x, resid, rhs_norm_sq);
            printf("T1_REFINEMENT step=%d mode_delta=%.12Lg original_relative_residual=%.12g\n",
                   it+1, (long double)mean_step, residual);
            if (!isfinite(residual)) return 2;
        }
        double end = omp_get_wtime();
        if (round == 9) totals = end-formal_start;
        if (residual >= 1e-4 || rounds == 1) {
            mem_usage();
            check_correctness_q_xq(n, ptr, col, val, x, rhs);
        }
        printf("CHECK round %d %s time : %.9f s\n", round+1, round<5 ? "warmup" : "formal", end-start);
        if (residual >= 1e-4) return 1;
    }
    if (rounds == 10) {
        printf("CHECK formal total time : %.9f s\n", totals);
        printf("CHECK end to end time : %.6f ms\n", 200*totals);
        mem_usage();
        check_correctness_q_xq(n, ptr, col, val, x, rhs);
    }
    destroy_block(&first);
    destroy_block(&last);
    HYPRE_Finalize();
    MPI_Finalize();
    free(x); free(resid); free(delta); free(d); free(dz); free(column_sum); free(middle_diag);
    free(ptr); free(col); free(val); free(rhs);
    return 0;
}
