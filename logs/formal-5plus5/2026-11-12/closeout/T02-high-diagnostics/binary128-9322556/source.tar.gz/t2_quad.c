#include <HYPRE_parcsr_mv.h>
#include <limits.h>
#include <mpi.h>
#include <quadmath.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "solverchallenge26/diagnostics.h"
#include "solverchallenge26/mpi_system_loader.h"
#include "solver.h"
#include "halo.h"

static void *allocate(size_t count, size_t size)
{
    void *p = calloc(count, size);
    if (!p) {
        fprintf(stderr, "Could not allocate %zu bytes\n", count*size);
        MPI_Abort(MPI_COMM_WORLD, 2);
    }
    return p;
}

static void hypre_check(HYPRE_Int result)
{
    if (result) {
        fprintf(stderr, "HYPRE error %d\n", (int)result);
        MPI_Abort(MPI_COMM_WORLD, 2);
    }
}

static void add_quad(void *src, void *dst, int *n, MPI_Datatype *type)
{
    const __float128 *a = src;
    __float128 *b = dst;
    for (int i = 0; i < *n; ++i) b[i] += a[i];
    (void)type;
}

static __float128 norm(const __float128 *a, int n, MPI_Datatype type, MPI_Op add)
{
    __float128 sum = 0;
    for (int i = 0; i < n; ++i) sum += a[i]*a[i];
    MPI_Allreduce(MPI_IN_PLACE, &sum, 1, type, add, MPI_COMM_WORLD);
    return sqrtq(sum);
}

static void project(__float128 *w, const __float128 *basis, int columns, int n,
                    __float128 *h, __float128 *dots, MPI_Datatype type, MPI_Op add)
{
    for (int pass = 0; pass < 2; ++pass) {
        for (int j = 0; j < columns; ++j) {
            const __float128 *v = basis+(size_t)j*n;
            __float128 sum = 0;
            for (int i = 0; i < n; ++i) sum += v[i]*w[i];
            dots[j] = sum;
        }
        MPI_Allreduce(MPI_IN_PLACE, dots, columns, type, add, MPI_COMM_WORLD);
        for (int j = 0; j < columns; ++j) {
            const __float128 *v = basis+(size_t)j*n;
            const __float128 d = dots[j];
            h[j] += d;
            for (int i = 0; i < n; ++i) w[i] -= d*v[i];
        }
    }
}

static __float128 true_residual(struct QuadHalo *halo, const struct SC26_SolverInput *in,
                                 const __float128 *x, __float128 *r,
                                 MPI_Datatype type, MPI_Op add)
{
    quad_matvec(halo, x, r);
    for (int i = 0; i < in->local_n; ++i) r[i] = (__float128)in->b[i]-r[i];
    return norm(r, in->local_n, type, add);
}

static void solve_quad(struct MySolver *s, struct QuadHalo *halo, const struct SC26_SolverInput *in,
                       int window, int cycles, __float128 *x, MPI_Datatype type, MPI_Op add,
                       int rank)
{
    const int n = in->local_n;
    const size_t stride = (size_t)window+1;
    const __float128 goal = 1e-11Q;
    __float128 *basis = allocate(stride*n, sizeof(*basis));
    double *directions = allocate((size_t)window*n, sizeof(*directions));
    __float128 *r = allocate(n, sizeof(*r));
    __float128 *qz = allocate(n, sizeof(*qz));
    double *rhs = allocate(n, sizeof(*rhs));
    __float128 *h = allocate(stride*window, sizeof(*h));
    __float128 *dots = allocate(window, sizeof(*dots));
    __float128 *g = allocate(stride, sizeof(*g));
    __float128 *c = allocate(window, sizeof(*c));
    __float128 *sn = allocate(window, sizeof(*sn));
    __float128 *y = allocate(window, sizeof(*y));
    for (int i = 0; i < n; ++i) r[i] = in->b[i];
    const __float128 bnorm = norm(r, n, type, add);
    __float128 beta = bnorm;
    for (int cycle = 0; cycle < cycles && beta > goal*bnorm; ++cycle) {
        memset(g, 0, stride*sizeof(*g));
        g[0] = beta;
        for (int i = 0; i < n; ++i) basis[i] = r[i]/beta;
        int used = 0;
        for (int j = 0; j < window; ++j) {
            __float128 *v = basis+(size_t)j*n;
            __float128 *w = v+n;
            double *z = directions+(size_t)j*n;
            __float128 *col = h+(size_t)j*stride;
            for (int i = 0; i < n; ++i) rhs[i] = (double)v[i];
            hypre_check(HYPRE_IJVectorSetValues(s->rhs, n, s->rows, rhs));
            hypre_check(HYPRE_ParVectorSetConstantValues(s->par_solution, 0));
            hypre_check(HYPRE_BoomerAMGSolve(s->amg, s->par_matrix, s->par_rhs, s->par_solution));
            hypre_check(HYPRE_IJVectorGetValues(s->solution, n, s->rows, z));
            for (int i = 0; i < n; ++i) qz[i] = z[i];
            quad_matvec(halo, qz, w);
            memset(col, 0, stride*sizeof(*col));
            project(w, basis, j+1, n, col, dots, type, add);
            const __float128 next = norm(w, n, type, add);
            col[j+1] = next;
            for (int k = 0; k < j; ++k) {
                const __float128 a = col[k], b = col[k+1];
                col[k] = c[k]*a+sn[k]*b;
                col[k+1] = -sn[k]*a+c[k]*b;
            }
            const __float128 scale = hypotq(col[j], next);
            if (!finiteq(scale) || scale == 0) break;
            c[j] = col[j]/scale;
            sn[j] = next/scale;
            col[j] = scale;
            col[j+1] = 0;
            g[j+1] = -sn[j]*g[j];
            g[j] *= c[j];
            used = j+1;
            if (!rank) {
                printf("T2_FGMRES cycle=%d step=%d estimated_relative_residual=%.12e\n",
                       cycle+1, used, (double)(fabsq(g[used])/bnorm));
                fflush(stdout);
            }
            if (fabsq(g[used]) <= goal*bnorm || next == 0) break;
            for (int i = 0; i < n; ++i) w[i] /= next;
        }
        if (!used) break;
        for (int j = used-1; j >= 0; --j) {
            __float128 z = g[j];
            for (int k = j+1; k < used; ++k) z -= h[(size_t)k*stride+j]*y[k];
            y[j] = z/h[(size_t)j*stride+j];
        }
        for (int j = 0; j < used; ++j) {
            const double *z = directions+(size_t)j*n;
            const __float128 a = y[j];
            for (int i = 0; i < n; ++i) x[i] += a*(__float128)z[i];
        }
        beta = true_residual(halo, in, x, r, type, add);
        if (!rank) {
            printf("T2_TRUE_RESIDUAL cycle=%d relative=%.12e\n", cycle+1, (double)(beta/bnorm));
            fflush(stdout);
        }
        if (!finiteq(beta)) break;
    }
    free(y); free(sn); free(c); free(g); free(dots); free(h); free(rhs);
    free(qz); free(r); free(directions); free(basis);
}

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    if (argc != 5) MPI_Abort(MPI_COMM_WORLD, 2);
    const int window = atoi(argv[3]), cycles = atoi(argv[4]);
    if (window < 1 || cycles < 1) MPI_Abort(MPI_COMM_WORLD, 2);

    MPI_Datatype quad_type;
    MPI_Op add;
    MPI_Type_contiguous(sizeof(__float128), MPI_BYTE, &quad_type);
    MPI_Type_commit(&quad_type);
    MPI_Op_create(add_quad, 1, &add);
    struct MPI_LocalSystem a;
    if (mpi_load_local_linear_system(argv[1], argv[2], 0, 0, MPI_COMM_WORLD, &a))
        MPI_Abort(MPI_COMM_WORLD, 2);
    struct SC26_SolverInput in = {
        .global_n=a.global_rows, .local_n=a.row_end-a.row_begin, .row_begin=a.row_begin,
        .row_ptr=a.row_ptr, .col_idx=a.col_idx, .val=a.val, .b=a.b, .comm=MPI_COMM_WORLD
    };
    __float128 *x = allocate(in.local_n, sizeof(*x));
    struct QuadHalo *halo = quad_halo_create(&in);
    struct MySolver s;
    create_iterative(&s, &in);
    hypre_check(HYPRE_BoomerAMGSetup(s.amg, s.par_matrix, s.par_rhs, s.par_solution));
    if (!rank) {
        printf("T2_BINARY128_FGMRES rows=%d mpi=%d restart=%d cycles=%d\n", in.global_n,size,window,cycles);
        fflush(stdout);
    }
    const double start = MPI_Wtime();
    solve_quad(&s, halo, &in, window, cycles, x, quad_type, add, rank);
    const __float128 xnorm = norm(x, in.local_n, quad_type, add);
    if (!rank) printf("T2_SOLUTION norm=%.12e time_seconds=%.6f\n", (double)xnorm, MPI_Wtime()-start);
    mem_usage();
    destroy_iterative(&s, &in);
    quad_halo_destroy(halo);

    __float128 *x_global = rank == 0 ? allocate(in.global_n, sizeof(*x_global)) : NULL;
    int *counts = allocate(size, sizeof(*counts));
    int *offsets = allocate(size, sizeof(*offsets));
    mpi_row_counts(in.global_n, size, counts, offsets);
    MPI_Gatherv(x, in.local_n, quad_type, x_global, counts, offsets, quad_type, 0, MPI_COMM_WORLD);
    free(x); free(counts); free(offsets);
    mpi_local_system_free(&a);
    if (!rank) {
        int m, n, nnz, symmetric, *ptr, *col;
        double *v, *vi, *b, *bi;
        if (load_linear_system(argv[1], argv[2], 0, 0, &m, &n, &nnz, &symmetric,
                               &ptr, &col, &v, &vi, &b, &bi))
            MPI_Abort(MPI_COMM_WORLD, 2);
        check_correctness_q_xq(n, ptr, col, v, x_global, b);
        free(x_global); free(ptr); free(col); free(v); free(b);
    }
    MPI_Op_free(&add);
    MPI_Type_free(&quad_type);
    MPI_Finalize();
    return 0;
}
