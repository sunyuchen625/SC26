from decimal import Decimal
from pathlib import Path
import re
import sys

text = Path(sys.argv[1]).read_text()
rounds = re.findall(r'^CHECK round (\d+) (warmup|formal) time : (\S+) s$', text, re.M)
assert [(int(i), phase) for i, phase, _ in rounds] == [
    (i, 'warmup' if i <= 5 else 'formal') for i in range(1, 11)
], 'Expected ten complete rounds'
total, = re.findall(r'^CHECK formal total time : (\S+) s$', text, re.M)
mean, = re.findall(r'^CHECK end to end time :\s+(\S+) ms$', text, re.M)
memory, = re.findall(r'^Total memory usage:\s+(\S+) MB$', text, re.M)
residual, = re.findall(r'^Q-Check \|\| b - Ax \|\| 2 / \|\| b \|\| 2\s+=\s+(\S+)$', text, re.M)
assert abs(Decimal(total)*200-Decimal(mean)) <= Decimal('0.000001')
assert Decimal(memory)*Decimal('0.001048576') <= 9, 'T1 official CPU memory exceeds 9 GB'
assert Decimal(residual) < Decimal('1e-4'), 'T1 official relative residual exceeds low grade'
print(f'FORMAL_5PLUS5_PASS total_s={total} mean_ms={mean} memory_MiB={memory}')
print(f'OFFICIAL_RESIDUAL_PASS relative_residual={residual} threshold=1e-4')
if Decimal(residual) < Decimal('1e-8'):
    print(f'OFFICIAL_RESIDUAL_PASS relative_residual={residual} threshold=1e-8')
