#!/bin/bash
set -euo pipefail

source_dir=$1
output=$2
cores=$3
scratch=$(mktemp -d "${SLURM_TMPDIR:-/tmp}/sc26-hypre-omp.XXXXXX")
trap 'rm -rf "$scratch"' EXIT

cmake -S "$source_dir" -B "$scratch/build" -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_C_COMPILER=mpicc -DCMAKE_INSTALL_PREFIX="$output" \
    -DCMAKE_INSTALL_LIBDIR=lib64 -DHYPRE_ENABLE_MPI=ON -DHYPRE_ENABLE_OPENMP=ON \
    -DHYPRE_BUILD_EXAMPLES=OFF -DHYPRE_BUILD_TESTS=OFF
cmake --build "$scratch/build" --parallel "$cores"
cmake --install "$scratch/build"
cp "$scratch/build/CMakeCache.txt" "$output/BuildCache.txt"
grep -E '^HYPRE_ENABLE_(MPI|OPENMP):' "$output/BuildCache.txt"
sha256sum "$output/lib64/libHYPRE.a"
