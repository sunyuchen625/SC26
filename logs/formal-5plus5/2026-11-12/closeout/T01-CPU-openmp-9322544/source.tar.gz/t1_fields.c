#include <HYPRE.h>
#include <HYPRE_IJ_mv.h>
#include <HYPRE_parcsr_ls.h>
#include <math.h>
#include <mpi.h>
#include <omp.h>
#include <quadmath.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "solverchallenge26/diagnostics.h"
#include "solverchallenge26/system_loader.h"

struct Block {
    HYPRE_IJMatrix matrix;
    HYPRE_IJVector rhs, sol;
    HYPRE_Solver amg, pcg;
    HYPRE_ParCSRMatrix par_matrix;
    HYPRE_ParVector par_rhs, par_sol;
    HYPRE_Int *indices;
    double *scale, *rhsval, *solval;
};

static void hypre_ok(int rc, const char *call)
{
    if (rc) {
        fprintf(stderr, "%s failed: %d\n", call, rc);
        exit(2);
    }
}

#define HYPRE_DO(call) hypre_ok((call), #call)

static void create_block(struct Block *block, int n)
{
    block->indices = malloc((size_t)n * sizeof(*block->indices));
    block->scale = malloc((size_t)n * sizeof(double));
    block->rhsval = malloc((size_t)n * sizeof(double));
    block->solval = calloc((size_t)n, sizeof(double));
    if (!block->indices || !block->scale || !block->rhsval || !block->solval)
        exit(2);
    for (int i = 0; i < n; ++i) block->indices[i] = i;

    HYPRE_DO(HYPRE_IJMatrixCreate(MPI_COMM_SELF, 0, n-1, 0, n-1, &block->matrix));
    HYPRE_DO(HYPRE_IJMatrixSetObjectType(block->matrix, HYPRE_PARCSR));
    HYPRE_Int *sizes = malloc((size_t)n * sizeof(*sizes));
    if (!sizes) exit(2);
    for (int i = 0; i < n; ++i) sizes[i] = 7;
    HYPRE_DO(HYPRE_IJMatrixSetRowSizes(block->matrix, sizes));
    free(sizes);
    HYPRE_DO(HYPRE_IJMatrixInitialize(block->matrix));

    HYPRE_DO(HYPRE_IJVectorCreate(MPI_COMM_SELF, 0, n-1, &block->rhs));
    HYPRE_DO(HYPRE_IJVectorSetObjectType(block->rhs, HYPRE_PARCSR));
    HYPRE_DO(HYPRE_IJVectorInitialize(block->rhs));
    HYPRE_DO(HYPRE_IJVectorAssemble(block->rhs));
    HYPRE_DO(HYPRE_IJVectorGetObject(block->rhs, (void **)&block->par_rhs));
    HYPRE_DO(HYPRE_IJVectorCreate(MPI_COMM_SELF, 0, n-1, &block->sol));
    HYPRE_DO(HYPRE_IJVectorSetObjectType(block->sol, HYPRE_PARCSR));
    HYPRE_DO(HYPRE_IJVectorInitialize(block->sol));
    HYPRE_DO(HYPRE_IJVectorAssemble(block->sol));
    HYPRE_DO(HYPRE_IJVectorGetObject(block->sol, (void **)&block->par_sol));

    HYPRE_DO(HYPRE_BoomerAMGCreate(&block->amg));
    HYPRE_DO(HYPRE_BoomerAMGSetCoarsenType(block->amg, 10));
    HYPRE_DO(HYPRE_BoomerAMGSetInterpType(block->amg, 6));
    HYPRE_DO(HYPRE_BoomerAMGSetPMaxElmts(block->amg, 4));
    HYPRE_DO(HYPRE_BoomerAMGSetStrongThreshold(block->amg, 0.5));
    HYPRE_DO(HYPRE_BoomerAMGSetRelaxType(block->amg, 6));
    HYPRE_DO(HYPRE_BoomerAMGSetMaxIter(block->amg, 1));
    HYPRE_DO(HYPRE_BoomerAMGSetTol(block->amg, 0));
    HYPRE_DO(HYPRE_ParCSRPCGCreate(MPI_COMM_SELF, &block->pcg));
    HYPRE_DO(HYPRE_ParCSRPCGSetMaxIter(block->pcg, 180));
    HYPRE_DO(HYPRE_ParCSRPCGSetTwoNorm(block->pcg, 1));
    HYPRE_DO(HYPRE_ParCSRPCGSetTol(block->pcg, 1e-10));
    HYPRE_DO(HYPRE_ParCSRPCGSetPrintLevel(block->pcg, 0));
    HYPRE_DO(HYPRE_ParCSRPCGSetLogging(block->pcg, 1));
    HYPRE_DO(HYPRE_ParCSRPCGSetPrecond(block->pcg, HYPRE_BoomerAMGSolve, HYPRE_BoomerAMGSetup, block->amg));
}

static void destroy_block(struct Block *block)
{
    HYPRE_DO(HYPRE_ParCSRPCGDestroy(block->pcg));
    HYPRE_DO(HYPRE_BoomerAMGDestroy(block->amg));
    HYPRE_DO(HYPRE_IJMatrixDestroy(block->matrix));
    HYPRE_DO(HYPRE_IJVectorDestroy(block->rhs));
    HYPRE_DO(HYPRE_IJVectorDestroy(block->sol));
    free(block->indices);
    free(block->scale);
    free(block->rhsval);
    free(block->solval);
}

static void build_block(struct Block *block, int n, int first, int anchor,
                        const int *ptr, const int *col, const double *val, const double *subtract)
{
    for (int i = 0; i < n; ++i) {
        double diag = 0;
        for (int k = ptr[first+i]; k < ptr[first+i+1]; ++k)
            if (col[k] == first+i) diag = val[k] - (subtract ? subtract[i] : 0);
        if (!(diag > 0)) exit(2);
        block->scale[i] = 1/sqrt(diag);
    }
    for (int begin = 0; begin < n; begin += 256) {
        HYPRE_Int counts[256], columns[7*256];
        double values[7*256];
        const int end = begin+256 < n ? begin+256 : n;
        int pos = 0;
        for (int i = begin; i < end; ++i) {
            const int start = pos;
            for (int k = ptr[first+i]; k < ptr[first+i+1]; ++k) {
                int j = col[k]-first;
                if (j < 0 || j >= n) continue;
                if ((i == anchor || j == anchor) && i != j) continue;
                if (pos-start == 7) exit(2);
                columns[pos] = j;
                const double entry = val[k] - (i == j && subtract ? subtract[i] : 0);
                values[pos++] = block->scale[i]*entry*block->scale[j];
            }
            counts[i-begin] = pos-start;
        }
        HYPRE_DO(HYPRE_IJMatrixSetValues(block->matrix, end-begin, counts,
            block->indices+begin, columns, values));
    }
    HYPRE_DO(HYPRE_IJMatrixAssemble(block->matrix));
    HYPRE_DO(HYPRE_IJMatrixGetObject(block->matrix, (void **)&block->par_matrix));
    HYPRE_DO(HYPRE_ParCSRPCGSetup(block->pcg, block->par_matrix, block->par_rhs, block->par_sol));
}

static void solve_block(struct Block *block, int n, int anchor,
                        const double *rhs, double *result, int field)
{
    for (int i = 0; i < n; ++i)
        block->rhsval[i] = i == anchor ? 0 : rhs[i]*block->scale[i];
    memset(block->solval, 0, (size_t)n * sizeof(double));
    HYPRE_DO(HYPRE_IJVectorSetValues(block->rhs, n, block->indices, block->rhsval));
    HYPRE_DO(HYPRE_IJVectorSetValues(block->sol, n, block->indices, block->solval));
    int rc = HYPRE_ParCSRPCGSolve(block->pcg, block->par_matrix, block->par_rhs, block->par_sol);
    if (rc & ~HYPRE_ERROR_CONV) hypre_ok(rc, "PCG solve");
    HYPRE_ClearAllErrors();
    HYPRE_Int iterations;
    HYPRE_Real residual;
    HYPRE_DO(HYPRE_ParCSRPCGGetNumIterations(block->pcg, &iterations));
    HYPRE_DO(HYPRE_ParCSRPCGGetFinalRelativeResidualNorm(block->pcg, &residual));
    printf("T1_BLOCK field=%d iterations=%d residual=%.6g\n", field, (int)iterations, (double)residual);
    if (!isfinite(residual)) exit(2);
    HYPRE_DO(HYPRE_IJVectorGetValues(block->sol, n, block->indices, block->solval));
    for (int i = 0; i < n; ++i) result[i] = block->solval[i]*block->scale[i];
}

struct Split {
    int cells, anchor;
    const int *ptr, *col;
    const double *val, *dz, *cross02, *cross20;
    const __float128 *column_sum;
    __float128 denominator;
    struct Block *first, *middle, *last;
};

static void block_inverse(const struct Split *split, const double *rhs,
                          double *work, double *delta, __float128 *z)
{
    const int cells = split->cells, third = 2*cells;
    memcpy(work, rhs, (size_t)3*cells*sizeof(*work));
    solve_block(split->middle, cells, -1, rhs+cells, delta+cells, 1);
    #pragma omp parallel for
    for (int i = 0; i < cells; ++i) {
        for (int k = split->ptr[i]; k < split->ptr[i+1]; ++k)
            if (split->col[k] >= cells && split->col[k] < third)
                work[i] -= split->val[k]*delta[split->col[k]];
        for (int k = split->ptr[third+i]; k < split->ptr[third+i+1]; ++k)
            if (split->col[k] >= cells && split->col[k] < third)
                work[third+i] -= split->val[k]*delta[split->col[k]];
    }
    solve_block(split->first, cells, -1, work, delta, 0);
    #pragma omp parallel for
    for (int i = 0; i < cells; ++i)
        work[third+i] -= split->cross20[i]*delta[i];
    solve_block(split->last, cells, split->anchor, work+third, delta+third, 2);
    __float128 numerator = 0;
    for (int i = 0; i < cells; ++i)
        numerator += (__float128)work[third+i] - split->column_sum[i]*delta[third+i];
    const __float128 mean = numerator/split->denominator;
    #pragma omp parallel for
    for (int i = 0; i < cells; ++i) {
        z[i] = delta[i];
        z[cells+i] = delta[cells+i];
        z[third+i] = delta[third+i] + mean*(1-(__float128)split->dz[i]);
    }
    #pragma omp parallel for
    for (int i = 0; i < cells; ++i) work[i] = (double)(-split->cross02[i]*z[third+i]);
    solve_block(split->first, cells, -1, work, delta, 0);
    #pragma omp parallel for
    for (int i = 0; i < cells; ++i) z[i] += delta[i];

    #pragma omp parallel for
    for (int i = cells; i < third; ++i) {
        __float128 residual = rhs[i];
        for (int k = split->ptr[i]; k < split->ptr[i+1]; ++k)
            if (split->col[k] < cells || split->col[k] >= third)
                residual -= (__float128)split->val[k]*z[split->col[k]];
        work[i] = (double)residual;
    }
    solve_block(split->middle, cells, -1, work+cells, delta+cells, 1);
    #pragma omp parallel for
    for (int i = cells; i < third; ++i) z[i] = delta[i];
}

static void schur_diagonals(int cells, const int *ptr, const int *col, const double *val,
                            double *s0, double *s2, double *cross02, double *cross20)
{
    double max_s0=0, max_s2=0, max_02=0, max_20=0;
    #pragma omp parallel for reduction(max:max_s0,max_s2,max_02,max_20)
    for (int i = 0; i < cells; ++i) {
        double local[3][3] = {{0}};
        for (int f = 0; f < 3; ++f) {
            int row = f*cells+i;
            for (int k = ptr[row]; k < ptr[row+1]; ++k)
                if (col[k]%cells == i)
                    local[f][col[k]/cells] = val[k];
        }
        const double dm=local[1][1];
        s0[i] = local[0][1]*(local[1][0]/dm);
        s2[i] = local[2][1]*(local[1][2]/dm);
        cross02[i] = local[0][2]-local[0][1]*(local[1][2]/dm);
        cross20[i] = local[2][0]-local[2][1]*(local[1][0]/dm);
        max_s0=fmax(max_s0,fabs(s0[i])); max_s2=fmax(max_s2,fabs(s2[i]));
        max_02=fmax(max_02,fabs(cross02[i])); max_20=fmax(max_20,fabs(cross20[i]));
    }
    printf("T1_SCHUR max_s0=%.8g max_s2=%.8g max_cross02=%.8g max_cross20=%.8g\n",
           max_s0,max_s2,max_02,max_20);
}

static double dot(int n, const double *a, const double *b)
{
    double sum = 0;
    #pragma omp parallel for reduction(+:sum)
    for (int i = 0; i < n; ++i) sum += a[i]*b[i];
    return sum;
}

enum { krylov = 8 };

static void krylov_step(const struct Split *split, int n, const double *resid,
                        double *work, double *delta, double *basis,
                        __float128 *updates, __float128 *x, double rhs_norm)
{
    double h[krylov+1][krylov] = {{0}}, cosines[krylov], sines[krylov];
    double g[krylov+1] = {sqrt(dot(n, resid, resid))}, y[krylov];
    if (g[0] == 0) return;
    #pragma omp parallel for
    for (int i = 0; i < n; ++i) basis[i] = resid[i]/g[0];

    int used = 0;
    for (int j = 0; j < krylov; ++j) {
        __float128 *z = updates+(size_t)j*n;
        double *w = basis+(size_t)(j+1)*n;
        block_inverse(split, basis+(size_t)j*n, work, delta, z);
        #pragma omp parallel for
        for (int i = 0; i < n; ++i) {
            __float128 value = 0;
            for (int k = split->ptr[i]; k < split->ptr[i+1]; ++k)
                value += (__float128)split->val[k]*z[split->col[k]];
            w[i] = (double)value;
        }
        for (int pass = 0; pass < 2; ++pass)
            for (int k = 0; k <= j; ++k) {
                const double *v = basis+(size_t)k*n;
                double projection = dot(n, w, v);
                h[k][j] += projection;
                #pragma omp parallel for
                for (int i = 0; i < n; ++i) w[i] -= projection*v[i];
            }
        double next = sqrt(dot(n, w, w));
        h[j+1][j] = next;
        if (next > 0) {
            #pragma omp parallel for
            for (int i = 0; i < n; ++i) w[i] /= next;
        }
        for (int k = 0; k < j; ++k) {
            double top = h[k][j], bottom = h[k+1][j];
            h[k][j] = cosines[k]*top+sines[k]*bottom;
            h[k+1][j] = -sines[k]*top+cosines[k]*bottom;
        }
        double scale = hypot(h[j][j],h[j+1][j]);
        if (!(scale > 0) || !isfinite(scale)) break;
        cosines[j] = h[j][j]/scale;
        sines[j] = h[j+1][j]/scale;
        h[j][j] = scale;
        h[j+1][j] = 0;
        g[j+1] = -sines[j]*g[j];
        g[j] *= cosines[j];
        used = j+1;
        printf("T1_FGMRES step=%d estimated_relative_residual=%.12g\n", used, fabs(g[used])/rhs_norm);
        if (fabs(g[used]) < 3e-10*rhs_norm || next == 0) break;
    }
    for (int j = used-1; j >= 0; --j) {
        double value = g[j];
        for (int k = j+1; k < used; ++k) value -= h[j][k]*y[k];
        y[j] = value/h[j][j];
    }
    #pragma omp parallel for
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < used; ++j)
            x[i] += (__float128)y[j]*updates[(size_t)j*n+i];
}

static double relative_residual(int n, const int *ptr, const int *col, const double *val,
                                const double *rhs, const __float128 *x, double *resid,
                                long double rhs_norm_sq)
{
    long double norm_sq = 0, field0 = 0, field1 = 0, field2 = 0;
    #pragma omp parallel for reduction(+:norm_sq,field0,field1,field2)
    for (int i = 0; i < n; ++i) {
        __float128 r = rhs[i];
        for (int k = ptr[i]; k < ptr[i+1]; ++k)
            r -= (__float128)val[k]*x[col[k]];
        resid[i] = (double)r;
        long double sq = (long double)r*(long double)r;
        norm_sq += sq;
        if (i < n/3) field0 += sq;
        else if (i < 2*n/3) field1 += sq;
        else field2 += sq;
    }
    printf("T1_FIELD_RESIDUAL %.8Lg %.8Lg %.8Lg\n",
           sqrtl(field0/rhs_norm_sq), sqrtl(field1/rhs_norm_sq), sqrtl(field2/rhs_norm_sq));
    return sqrtl(norm_sq/rhs_norm_sq);
}

static void store_solution(int n, const __float128 *x)
{
    FILE *file = fopen("answer_x.rhs", "w");
    if (!file) {
        perror("answer_x.rhs");
        exit(2);
    }
    fprintf(file, "%d\n", n);
    for (int i = 0; i < n; ++i) {
        char line[72];
        quadmath_snprintf(line, sizeof(line), "%.36Qe", x[i]);
        fprintf(file, "%s\n", line);
    }
    if (fclose(file) != 0) {
        perror("answer_x.rhs");
        exit(2);
    }
}

int main(int argc, char **argv)
{
    if (argc != 3 && !(argc == 4 && !strcmp(argv[3], "--probe"))) return 2;
    MPI_Init(&argc, &argv);
    HYPRE_DO(HYPRE_Initialize());
    int m, n, nnz, symmetric, *ptr, *col;
    double *val, *imag, *rhs, *rhs_imag;
    if (load_linear_system(argv[1], argv[2], 0, 0, &m, &n, &nnz, &symmetric, &ptr,
        &col, &val, &imag, &rhs, &rhs_imag) || m != n || n % 3) return 2;
    const int cells = n/3, third = 2*cells;
    printf("T1_MATRIX rows=%d nnz=%d cells=%d\n", n, nnz, cells);
    __float128 *x = calloc((size_t)n, sizeof(*x));
    double *resid = malloc((size_t)n*sizeof(double));
    double *delta = malloc((size_t)n*sizeof(double));
    double *d = malloc((size_t)cells*sizeof(double));
    double *dz = malloc((size_t)cells*sizeof(double));
    __float128 *column_sum = calloc((size_t)cells, sizeof(*column_sum));
    if (!x || !resid || !delta || !d || !dz || !column_sum) return 2;
    double *s0 = malloc((size_t)cells*sizeof(*s0));
    double *s2 = malloc((size_t)cells*sizeof(*s2));
    double *cross02 = malloc((size_t)cells*sizeof(*cross02));
    double *cross20 = malloc((size_t)cells*sizeof(*cross20));
    double *work = malloc((size_t)n*sizeof(*work));
    double *basis = malloc((size_t)(krylov+1)*n*sizeof(*basis));
    __float128 *updates = malloc((size_t)krylov*n*sizeof(*updates));
    if (!work || !basis || !updates || !s0 || !s2 || !cross02 || !cross20) return 2;
    long double rhs_norm_sq = 0;
    for (int i = 0; i < n; ++i) rhs_norm_sq += (long double)rhs[i]*rhs[i];
    struct Block first, middle, last;
    create_block(&first, cells);
    create_block(&middle, cells);
    create_block(&last, cells);

    const int rounds = argc == 4 ? 1 : 10;
    double formal_start = 0, totals = 0;
    for (int round = 0; round < rounds; ++round) {
        const double start = omp_get_wtime();
        if (round == 5) formal_start = start;
        memset(x, 0, (size_t)n*sizeof(*x));
        memset(column_sum, 0, (size_t)cells*sizeof(*column_sum));
        memcpy(resid, rhs, (size_t)n*sizeof(double));
        schur_diagonals(cells,ptr,col,val,s0,s2,cross02,cross20);
        int anchor = -1;
        double anchor_diag = 0;
        __float128 sum_rows = 0;
        for (int i = 0; i < cells; ++i) {
            __float128 row_sum = 0;
            for (int k = ptr[third+i]; k < ptr[third+i+1]; ++k) {
                int j = col[k]-third;
                if (j < 0) continue;
                column_sum[j] += val[k];
                row_sum += val[k];
                if (i == j && val[k] > anchor_diag) {
                    anchor = i;
                    anchor_diag = val[k];
                }
            }
            column_sum[i] -= s2[i];
            row_sum -= s2[i];
            d[i] = (double)row_sum;
            sum_rows += row_sum;
        }
        if (anchor < 0) return 2;
        printf("T1_MODE anchor=%d anchor_diag=%.12g row_sum=%.12Lg\n",
               anchor, anchor_diag, (long double)sum_rows);
        build_block(&first, cells, 0, -1, ptr, col, val, s0);
        build_block(&middle, cells, cells, -1, ptr, col, val, NULL);
        build_block(&last, cells, third, anchor, ptr, col, val, s2);
        solve_block(&last, cells, anchor, d, dz, 2);
        __float128 denominator = 0;
        for (int i = 0; i < cells; ++i)
            denominator += column_sum[i]*(1-(__float128)dz[i]);
        printf("T1_MODE denominator=%.12Lg\n", (long double)denominator);
        if (denominator == 0) {
            fprintf(stderr, "T1 field-2 constant mode is singular under block splitting.\n");
            return 2;
        }
        struct Split split = {cells, anchor, ptr, col, val, dz, cross02, cross20,
                              column_sum, denominator, &first, &middle, &last};
        block_inverse(&split, rhs, work, delta, x);
        double residual = relative_residual(n, ptr, col, val, rhs, x, resid, rhs_norm_sq);
        printf("T1_REFINEMENT step=0 original_relative_residual=%.12g\n", residual);
        for (int cycle = 0; cycle < 3 && residual > 3e-10; ++cycle) {
            krylov_step(&split, n, resid, work, delta, basis, updates, x, sqrtl(rhs_norm_sq));
            residual = relative_residual(n, ptr, col, val, rhs, x, resid, rhs_norm_sq);
            printf("T1_REFINEMENT step=%d original_relative_residual=%.12g\n", cycle+1, residual);
            if (!isfinite(residual)) return 2;
        }
        double end = omp_get_wtime();
        if (round == 9) totals = end-formal_start;
        if (residual >= 1e-4 || rounds == 1) {
            mem_usage();
            check_correctness_q_xq(n, ptr, col, val, x, rhs);
        }
        printf("CHECK round %d %s time : %.9f s\n", round+1, round<5 ? "warmup" : "formal", end-start);
        if (residual >= 1e-4) return 1;
    }
    if (rounds == 10) {
        printf("CHECK formal total time : %.9f s\n", totals);
        printf("CHECK end to end time : %.6f ms\n", 200*totals);
        mem_usage();
        check_correctness_q_xq(n, ptr, col, val, x, rhs);
        store_solution(n, x);
    }
    destroy_block(&first);
    destroy_block(&middle);
    destroy_block(&last);
    HYPRE_Finalize();
    MPI_Finalize();
    free(s0); free(s2); free(cross02); free(cross20);
    free(work); free(basis); free(updates);
    free(x); free(resid); free(delta); free(d); free(dz); free(column_sum);
    free(ptr); free(col); free(val); free(rhs);
    return 0;
}
