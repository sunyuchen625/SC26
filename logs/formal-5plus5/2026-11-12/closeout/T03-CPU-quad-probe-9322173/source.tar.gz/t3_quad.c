/*
 * SolverChallenge26 T3.
 * Double-precision sparse LU supplies corrections to a binary128 solution.
 */
#include <math.h>
#include <mkl.h>
#include <omp.h>
#include <quadmath.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "solverchallenge26/residual_check.h"
#include "solverchallenge26/system_loader.h"

static void run_phase(void **handle, MKL_INT *parameters, MKL_INT phase, MKL_INT n,
                      const int *rows, const int *cols, const double *values,
                      double *rhs, double *solution)
{
    const MKL_INT one = 1, zero = 0, unsymmetric = 11;
    MKL_INT error;
    pardiso(handle, &one, &one, &unsymmetric, &phase, &n, values, rows, cols,
            &zero, &one, parameters, &one, rhs, solution, &error);
    if (error != 0) {
        fprintf(stderr, "PARDISO phase %d failed: %d\n", (int)phase, (int)error);
        exit(EXIT_FAILURE);
    }
}

static void store_quad_solution(int n, const __float128 *x)
{
    FILE *file = fopen("answer_x.rhs", "w");
    if (file == NULL) {
        perror("answer_x.rhs");
        exit(EXIT_FAILURE);
    }
    fprintf(file, "%d\n", n);
    for (int i = 0; i < n; ++i) {
        char line[72];
        quadmath_snprintf(line, sizeof(line), "%.36Qe", x[i]);
        fprintf(file, "%s\n", line);
    }
    if (fclose(file) != 0) {
        perror("answer_x.rhs");
        exit(EXIT_FAILURE);
    }
}

int main(int argc, char **argv)
{
    const bool probe = argc == 4 && strcmp(argv[3], "--probe") == 0;
    if (argc != 3 && !probe) {
        fprintf(stderr, "Usage: %s A.dat b.dat [--probe]\n", argv[0]);
        return EXIT_FAILURE;
    }

    int m, n, nnz, symmetric, *rows = NULL, *cols = NULL;
    double *a = NULL, *a_im = NULL, *b = NULL, *b_im = NULL;
    if (load_linear_system(argv[1], argv[2], 0, 0, &m, &n, &nnz, &symmetric,
                           &rows, &cols, &a, &a_im, &b, &b_im) != 0 || m != n) {
        fprintf(stderr, "T3 requires a square real matrix and matching RHS.\n");
        return EXIT_FAILURE;
    }

    double *scaled_a = malloc((size_t)nnz * sizeof(*scaled_a));
    double *scale = malloc((size_t)n * sizeof(*scale));
    double *rhs = malloc((size_t)n * sizeof(*rhs));
    double *correction = malloc((size_t)n * sizeof(*correction));
    __float128 *x = malloc((size_t)n * sizeof(*x));
    if (!scaled_a || !scale || !rhs || !correction || !x) {
        fprintf(stderr, "Could not allocate T3 work arrays.\n");
        return EXIT_FAILURE;
    }

    const MKL_INT unsymmetric = 11;
    MKL_INT parameters[64];
    void *handle[64];
    pardisoinit(handle, &unsymmetric, parameters);
    parameters[1] = 2;
    parameters[7] = 0;
    parameters[10] = 0;
    parameters[12] = 0;
    parameters[26] = 1;
    parameters[34] = 1;

    double formal_start = 0.0, formal_total = 0.0, round_time[10];
    const int rounds = probe ? 1 : 10;
    const __float128 target = 5e-10Q;
    __float128 relative_residual = HUGE_VALQ;
    bool passed_all_rounds = true;
    for (int round = 0; round < rounds; ++round) {
        const double started = omp_get_wtime();
        if (round == 5)
            formal_start = started;

        run_phase(handle, parameters, 11, n, rows, cols, NULL, rhs, correction);
        const double analysed = omp_get_wtime();
        printf("T3_PARDISO_ANALYSE seconds=%.6f\n", analysed - started);

        /* Power-of-two equilibration preserves the original binary64 coefficients. */
        #pragma omp parallel for schedule(static)
        for (int i = 0; i < n; ++i) {
            double row_maximum = 0.0;
            for (int k = rows[i]; k < rows[i + 1]; ++k)
                row_maximum = fmax(row_maximum, fabs(a[k]));
            scale[i] = row_maximum == 0.0 ? 1.0 : scalbn(1.0, -ilogb(row_maximum) / 2);
            rhs[i] = scale[i] * b[i];
        }
        #pragma omp parallel for schedule(static)
        for (int i = 0; i < n; ++i)
            for (int k = rows[i]; k < rows[i + 1]; ++k)
                scaled_a[k] = (scale[i] * a[k]) * scale[cols[k]];
        run_phase(handle, parameters, 22, n, rows, cols, scaled_a, rhs, correction);
        const double factored = omp_get_wtime();
        printf("T3_PARDISO_FACTOR seconds=%.6f perturbed_pivots=%d\n",
               factored - analysed, (int)parameters[13]);
        run_phase(handle, parameters, 33, n, rows, cols, scaled_a, rhs, correction);

        __float128 b_squared = 0.0Q;
        #pragma omp parallel for reduction(+:b_squared) schedule(static)
        for (int i = 0; i < n; ++i) {
            x[i] = (__float128)scale[i] * correction[i];
            b_squared += (__float128)b[i] * b[i];
        }

        int steps;
        for (steps = 0; steps <= 8; ++steps) {
            __float128 r_squared = 0.0Q;
            #pragma omp parallel for reduction(+:r_squared) schedule(static)
            for (int i = 0; i < n; ++i) {
                __float128 residual = b[i];
                for (int k = rows[i]; k < rows[i + 1]; ++k)
                    residual -= (__float128)a[k] * x[cols[k]];
                rhs[i] = (double)((__float128)scale[i] * residual);
                r_squared += residual * residual;
            }
            relative_residual = b_squared > 0 ? sqrtq(r_squared / b_squared) : sqrtq(r_squared);
            printf("T3_QUAD_REFINEMENT step=%d relative_residual=%.12e\n",
                   steps, (double)relative_residual);
            if (relative_residual < target || !isfinite((double)relative_residual) || steps == 8)
                break;
            run_phase(handle, parameters, 33, n, rows, cols, scaled_a, rhs, correction);
            #pragma omp parallel for schedule(static)
            for (int i = 0; i < n; ++i)
                x[i] += (__float128)scale[i] * correction[i];
        }
        const double ended = omp_get_wtime();
        round_time[round] = ended - started;
        if (round == 9)
            formal_total = ended - formal_start;
        printf("T3_PARDISO_DONE refinements=%d\n", steps);
        passed_all_rounds = passed_all_rounds && relative_residual < 1e-8Q;
        if (!passed_all_rounds)
            break;
    }

    run_phase(handle, parameters, -1, n, rows, cols, scaled_a, rhs, correction);
    if (passed_all_rounds && !probe) {
        for (int i = 0; i < rounds; ++i)
            printf("CHECK round %d %s time : %.9f s\n", i + 1, i < 5 ? "warmup" : "formal", round_time[i]);
        printf("CHECK formal total time : %.9f s\n", formal_total);
        printf("CHECK end to end time : %12.6f ms\n", formal_total * 200.0);
    }
    mem_usage();
    check_correctness_q_xq(n, rows, cols, a, x, b);
    if (passed_all_rounds && !probe)
        store_quad_solution(n, x);

    free(x);
    free(correction);
    free(rhs);
    free(scale);
    free(scaled_a);
    free(b);
    free(a);
    free(cols);
    free(rows);
    return passed_all_rounds ? EXIT_SUCCESS : EXIT_FAILURE;
}
