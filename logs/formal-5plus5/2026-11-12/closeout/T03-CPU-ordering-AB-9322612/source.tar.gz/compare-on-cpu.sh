#!/bin/bash
set -euo pipefail
root=$PWD
data=/data/home/maorz/SolverChallenge26-TenProblems/solverchallenge26_03
matrix="$data/solverchallenge26_03_A.dat"
rhs="$data/solverchallenge26_03_b.dat"
run="$root/runs/$SLURM_JOB_ID"
mkdir -p "$run"
cd "$run"
printf 'T3_ORDERING_AFFINITY '
taskset -pc "$$"
sha256sum "$matrix" "$rhs"
python3 - <<'PYFIXTURE'
from pathlib import Path
import struct
Path("smoke_A.dat").write_bytes(struct.pack(">10i4d", 1211216, 2, 2, 4, 2, 2, 0, 1, 0, 1, 4., 1., 2., 3.))
Path("smoke_b.dat").write_bytes(struct.pack(">2i2d", 1211214, 2, 2., -4.))
PYFIXTURE
for ordering in 2 3; do
    mkdir "$run/$ordering"
    cd "$run/$ordering"
    solver="$root/t3-ordering-$ordering"
    stdbuf -oL "$solver" ../smoke_A.dat ../smoke_b.dat --probe >smoke.log
    python3 - <<'PY'
from pathlib import Path
import re
residual, = re.findall(r'^Q-Check \|\| b - Ax \|\| 2 / \|\| b \|\| 2 =\s+(\S+)', Path("smoke.log").read_text(), re.M)
assert 0 <= float(residual) < 1e-12, residual
PY
    printf 'T3_ORDERING_BEGIN iparm[1]=%s\n' "$ordering"
    printf 'T3_SMOKE_PASS official_quad_checker=check_correctness_q_xq\n'
    printf 'SC26_RUN problem=03 rhs=01 node=%s mpi=1 threads=%s ordering=%s\n' \
        "$SLURMD_NODENAME" "$OMP_NUM_THREADS" "$ordering"
    set +e
    /data/home/sunyc/solverchallenge26/deps/gnu-time/time -v -o process.time \
        stdbuf -oL "$solver" "$matrix" "$rhs" | tee solver.log
    status=${PIPESTATUS[0]}
    set -e
    printf '%s\n' "$status" > process.exit
    if [[ $status != 0 ]]; then exit "$status"; fi
    python3 "$root/check_result.py" solver.log 1e-8 --formal | tee verification.log
    printf 'T3_ORDERING_PASS iparm[1]=%s\n' "$ordering"
done
