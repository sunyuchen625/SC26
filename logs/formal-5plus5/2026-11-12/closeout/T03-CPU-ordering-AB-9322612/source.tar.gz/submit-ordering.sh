#!/bin/bash
set -euo pipefail
export LC_ALL=C
cd /data/home/sunyc/solverchallenge26/formal-20261113-t3-ordering
date '+%F %T %Z'
printf 'SC26 T03 commercial CPU | PARDISO ordering 2 and 3 | same 16 cores | each 5+5\n'
submit=(sbatch --parsable --chdir="$PWD" --output="$PWD/slurm-%j.out" --error="$PWD/slurm-%j.err" ./run-ordering.sbatch)
printf '+'
printf ' %q' "${submit[@]}"
printf '\n'
job=$("${submit[@]}")
job=${job%%;*}
printf '%s\n' "$job" > job.id
printf 'Submitted Slurm job %s\n' "$job"
out="slurm-$job.out"
seen=0
drain_output() {
    [[ -s "$out" ]] || return 0
    local end
    end=$(wc -l < "$out")
    if (( end > seen )); then
        sed -n "$((seen+1)),${end}p" "$out" |
            awk '/^([[:xdigit:]]{64} |T3_(ORDERING_|SMOKE_PASS|QUAD_REFINEMENT|PARDISO_)|SC26_RUN|CHECK |Q-Check|Total memory usage|FORMAL_5PLUS5_PASS|OFFICIAL_RESIDUAL_PASS|Time spent in reordering of the initial matrix)/'
        seen=$end
    fi
}
previous=
while :; do
    drain_output
    status=$(sacct -n -X -P -j "$job" -o State,ExitCode,NodeList,Elapsed | head -n1)
    state=${status%%|*}
    if [[ -n "$state" && "$state" != "$previous" ]]; then
        printf '%s JOB %s %s\n' "$(date '+%F %T %Z')" "$job" "$status"
        previous=$state
    fi
    case "$state" in
        COMPLETED|FAILED|TIMEOUT|OUT_OF_MEMORY|NODE_FAIL|PREEMPTED|CANCELLED*) break ;;
    esac
    sleep 3
done
drain_output
sacct -j "$job" -P -o JobID,State,ExitCode,Start,End,Elapsed,NodeList,AllocTRES
if [[ $status == COMPLETED\|0:0\|* ]] && [[ $(grep -c '^T3_ORDERING_PASS ' "$out") == 2 ]]; then
    printf 'Job %s completed successfully\n' "$job"
else
    printf 'Job %s ended with %s\n' "$job" "$status"
    [[ ! -s slurm-$job.err ]] || tail -n 18 "slurm-$job.err"
    exit 1
fi
